/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joagosti <joagosti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/25 13:31:22 by joagosti          #+#    #+#             */
/*   Updated: 2021/06/04 17:05:42 by joagosti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int main()
{
	int i = 0;
	t_liste *liste_a;
	t_liste *liste_b;
	
	liste_a = initialisation();
	liste_b = initialisation();
	
	insertion_top(liste_a, 4);
	insertion_top(liste_a, 8);
	insertion_top(liste_a, 15);
	insertion_top(liste_a, 112);
	insertion_top(liste_a, 1);
	insertion_top(liste_a, 6);
	insertion_top(liste_a, 21);
	insertion_top(liste_a, 35);
	insertion_top(liste_a, 42);
	insertion_top(liste_a, 69);
	insertion_top(liste_a, 420);
	insertion_top(liste_a, 5);
	printf("PILE A: ");
	afficherListe(liste_a);
	i++;
	printf("%d=======================\n", i);

	swap_a(liste_a);
	printf("PILE A: ");
	afficherListe(liste_a);
	i++;
	printf("%d=======================\n", i);

	push_b(liste_a, liste_b);
	push_b(liste_a, liste_b);
	push_b(liste_a, liste_b);
	push_b(liste_a, liste_b);
	push_b(liste_a, liste_b);
	push_b(liste_a, liste_b);
	printf("PILE A: ");
	afficherListe(liste_a);
	printf("PILE B: ");
	afficherListe(liste_b);

	push_a(liste_a, liste_b);
	push_a(liste_a, liste_b);
	push_a(liste_a, liste_b);
	printf("PILE A: ");
	afficherListe(liste_a);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);

	rotate_a(liste_a);
	printf("PILE A: ");
	afficherListe(liste_a);
	i++;
	printf("%d=======================\n", i);

	rotate_b(liste_b);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);

	swap_s(liste_a, liste_b);
	printf("PILE A: ");
	afficherListe(liste_a);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);
	
	rotate_r(liste_a, liste_b);
	printf("PILE A: ");
	afficherListe(liste_a);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);

	r_rotate_a(liste_a);
	printf("PILE A: ");
	afficherListe(liste_a);
	i++;
	printf("%d=======================\n", i);

	r_rotate_a(liste_a);
	printf("PILE A: ");
	afficherListe(liste_a);
	i++;
	printf("%d=======================\n", i);

	r_rotate_b(liste_b);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);

	r_rotate_b(liste_b);
	printf("PILE B: ");
	afficherListe(liste_b);
	i++;
	printf("%d=======================\n", i);

	r_rotate_r(liste_a, liste_b);
	printf("PILE A: ");
	afficherListe(liste_a);
	printf("PILE B: ");
	afficherListe(liste_b);
	
	return 0;
}

// int	main(int argc, char **argv)
// {
// 	int	*tab;
// 	int median; 

// 	tab = malloc(sizeof(int) * (argc - 1));
// 	if (!tab)
// 		return (-1);
// 	*tab = arg_isvalid(argc, argv);
// 	median = 0;
// }

// t_pile *ft_init_pile(t_pile *pile)
// {
// 	pile->nb = 0;
// 	pile->next = NULL; 
// }

// void	creat_pile_a(void)
// {
// 	return (1);
// }
