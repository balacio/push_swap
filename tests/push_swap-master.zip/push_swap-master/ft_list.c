/* ************************************************************************** */
/*																			*/
/*														:::	  ::::::::   */
/*   ft_list.c										  :+:	  :+:	:+:   */
/*													+:+ +:+		 +:+	 */
/*   By: joagosti <joagosti@student.42.fr>		  +#+  +:+	   +#+		*/
/*												+#+#+#+#+#+   +#+		   */
/*   Created: 2021/06/03 11:26:46 by joagosti		  #+#	#+#			 */
/*   Updated: 2021/06/04 10:15:22 by joagosti		 ###   ########.fr	   */
/*																			*/
/* ************************************************************************** */

#include "push_swap.h"

t_liste	*initialisation(void)
{
	t_liste		*liste;
	t_element	*element;

	liste = (t_liste *)malloc(sizeof (t_liste));
	element = (t_element *)malloc(sizeof (t_element));
	if ((!liste) || (!element))
		exit(EXIT_FAILURE);
	liste->premier = NULL;
	return (liste);
}

void	insertion_top(t_liste *liste, int nvNombre)
{
	t_element	*nouveau;

	nouveau = (t_element *)malloc(sizeof (t_element));
	if (!nouveau)
		exit(EXIT_FAILURE);
	nouveau->nombre = nvNombre;
	nouveau->suivant = liste->premier;
	liste->premier = nouveau;
}

void	insertion_bottom(t_liste *liste, t_element *actuel, int nvNombre)
{
	t_element	*nouveau;

	nouveau = (t_element *)malloc(sizeof (t_element));
	if (!nouveau)
		exit(EXIT_FAILURE);
	nouveau->nombre = nvNombre;
	nouveau->suivant = NULL;
	actuel->suivant = nouveau;
}

void	suppression_top(t_liste *liste)
{
	t_element	*a_supprimer;

	if (liste == NULL)
		exit(EXIT_FAILURE);
	if (liste->premier != NULL)
	{
		a_supprimer = liste->premier;
		liste->premier = liste->premier->suivant;
		free(a_supprimer);
	}
}

void	suppression_bottom(t_liste *liste)
{
	t_element	*a_supprimer;

	if (liste == NULL)
		exit(EXIT_FAILURE);
	if (liste->premier != NULL)
	{
		a_supprimer = liste->premier;
		while (a_supprimer->suivant->suivant != NULL)
			a_supprimer = a_supprimer->suivant;
		a_supprimer->suivant = NULL;
		free(a_supprimer);
	}
}

void	afficherListe(t_liste *liste)
{
	t_element	*actuel;
	int	i;

	i = 0;
	if (liste == NULL)
		exit(EXIT_FAILURE);
	actuel = liste->premier;
	while (actuel != NULL)
	{
		printf("%d -> ", actuel->nombre);
		actuel = actuel->suivant;
		i++;
	}
	printf("NULL\n");
}
