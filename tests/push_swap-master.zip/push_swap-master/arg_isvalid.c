/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   arg_isvalid.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joagosti <joagosti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/25 15:58:45 by joagosti          #+#    #+#             */
/*   Updated: 2021/06/04 09:14:55 by joagosti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include <limits.h>
#include <stdio.h>

int	print_error(void)
{
	write(2, "Error\n", 6);
	exit(2);
}

void	ft_strcmp_2(char *s1)
{
	char	*s2;
	char	*s3;
	int		err1;
	int		err2;

	s2 = "-";
	s3 = "+";
	while ((*s1 == *s2 && *s1 && *s2) || (*s1 == *s3 && *s1 && *s3))
	{
		s1++;
		s2++;
		s3++;
	}
	err1 = *s1 - *s2;
	err2 = *s1 - *s3;
	if ((err1 == 0) || (err2 == 0))
		print_error();
}

int	ft_atoi_2(const char *str)
{
	long int	res;
	int			neg;

	res = 0;
	neg = 1;
	while (*str && (*str == ' ' || *str == '\t' || *str == '\f'
			|| *str == '\n' || *str == '\r' || *str == '\v'))
		++str;
	if (*str == '-')
		neg = -1;
	if (*str == '-' || *str == '+')
		++str;
	while (*str && '0' <= *str && *str <= '9')
	{
		res = res * 10 + (*str - 48);
		if (res > INT_MAX || res < INT_MIN)
			print_error();
		++str;
	}
	if ((*str && !('0' <= *str && *str <= '9')))
		print_error();
	res = res * neg;
	return (res);
}

int	check_double (int temp, int j, int *tab)
{
	while (j >= 0)
	{
		if (temp == tab[j])
			return (0);
		j--;
	}
	return (1);
}

int	arg_isvalid(int argc, char **argv)
{
	int	i;
	int	j;
	int	*tab;
	int	temp;

	i = 1;
	j = 0;
	tab = malloc(sizeof(int) * (argc - 1));
	if (!tab)
		return (-1);
	while (argc > 1 && i < argc)
	{
		ft_strcmp_2(argv[i]);
		temp = ft_atoi_2(argv[i]);
		if (j == 0)
			tab[j] = temp;
		else if (check_double(temp, j, tab) == 1)
			tab[j] = temp;
		else if (check_double(temp, j, tab) == 0)
			print_error();
		i++;
		j++;
	}
	return (*tab);
}
