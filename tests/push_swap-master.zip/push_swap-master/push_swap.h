/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joagosti <joagosti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/25 12:10:10 by joagosti          #+#    #+#             */
/*   Updated: 2021/06/04 17:45:55 by joagosti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>

typedef struct s_element
{
	int					nombre;
	struct s_element	*suivant;
}						t_element;

typedef struct s_liste
{
	t_element	*premier;
}				t_liste;

int		print_error(void);
void	ft_strcmp_2(char *s1);
int		ft_atoi_2(const char *str);
int		check_double (int temp, int j, int *tab);
int		arg_isvalid(int argc, char **argv);
t_liste	*initialisation(void);
void	insertion_top(t_liste *liste, int nvNombre);
void	insertion_bottom(t_liste *liste, t_element *actuel, int nvNombre);
void	afficherListe(t_liste *liste);
void	suppression_top(t_liste *liste);
void	suppression_bottom(t_liste *liste);
int		list_size(t_liste *liste);
int		*ft_sort_int_tab(int *tab, int argc);
int		ft_median(int argc);
void	push_a(t_liste *liste_a, t_liste *liste_b);
void	push_b(t_liste *liste_a, t_liste *liste_b);
void	r_rotate_a(t_liste *liste_a);
void	r_rotate_b(t_liste *liste_b);
void	r_rotate_r(t_liste *liste_a, t_liste *liste_b);
void	rotate_a(t_liste *liste_a);
void	rotate_b(t_liste *liste_b);
void	rotate_r(t_liste *liste_a, t_liste *liste_b);
void	swap_a(t_liste *liste);
void	swap_b(t_liste *liste);
void	swap_s(t_liste *liste_a, t_liste *liste_b);

#endif